
public class Java {

	public static void main(String[] args) 
	{
		System.out.println("Name : Ahmad Hamdan");
		System.out.println("Age : 24 ");
		System.out.println("HomeTown : Ramallah ");
	}	
		
		
	}