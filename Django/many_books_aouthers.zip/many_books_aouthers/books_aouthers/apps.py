from django.apps import AppConfig


class BooksAouthersConfig(AppConfig):
    name = 'books_aouthers'
