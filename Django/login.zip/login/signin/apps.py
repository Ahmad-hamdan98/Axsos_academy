from django.apps import AppConfig


class SigninConfig(AppConfig):
    name = 'signin'
