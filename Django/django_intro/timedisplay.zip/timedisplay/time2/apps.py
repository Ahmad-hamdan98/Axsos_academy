from django.apps import AppConfig


class Time2Config(AppConfig):
    name = 'time2'
