from django.apps import AppConfig


class BooksaoutherConfig(AppConfig):
    name = 'booksAouther'
